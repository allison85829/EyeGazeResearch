# IntelliJ Configuration

1. Press <kbd>Ctrl</kbd> + <kbd>Alt</kbd> + <kbd>S</kbd>
2. Go to "Editor > Code Style"
3. Click "Manage..." (right of "Scheme:")
4. Click "Import..."
5. Choose `IntelliJ Code Style.xml`
6. Press "OK"
7. Press "OK"
8. Press "Close"
9. Press "OK"

* Please let `.editorconfig` override the settings of IntelliJ
