package net.sf.jabref.logic.l10n;

enum LocalizationBundle {
    LANG, MENU
}
